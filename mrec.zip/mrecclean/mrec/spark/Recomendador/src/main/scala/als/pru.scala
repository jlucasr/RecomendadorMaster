package als

import org.apache.log4j.{ Level, Logger }
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{ SparkConf, SparkContext }
import org.apache.spark.sql.{ DataFrame, SQLContext }



object pru extends App{

  //val conf = new SparkConf().setMaster("local[*]").setAppName("Spark con Hive").set("spark.executor.memory", "2g")
  //.set("spark.driver.memory", "2g").set("spark.yarn.driver.memoryOverhead", "1g")
  //System.setProperty("hive.metastore.uris", "thrift://localhost:9083");
  
  val conf = new SparkConf().setMaster("local[2]").setAppName("My App")
  val sc = new SparkContext(conf)
  System.setProperty("hive.metastore.uris", "thrift://quickstart.cloudera:9083");
  System.setProperty("hive.tez.container.size", "4000")
  System.setProperty(" hive.tez.java.opts", "-Xmx3400m")
  
  //val sc = new SparkContext(conf)
  //val hiveContext = new HiveContext(sc)
  val hiveContext = new org.apache.spark.sql.hive.HiveContext(sc)


  try {
    // consulta Hive para obtener artid diferentes:
    //val ratingsDF: DataFrame = hiveContext.sql("SELECT * FROM practica.eventos")
    hiveContext.sql("SELECT * FROM practica.eventos")
    
  } finally {
    sc.stop()
  }
  
}