package als

import org.apache.log4j.{ Level, Logger }
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{ SparkConf, SparkContext }
import org.apache.spark.sql.{ DataFrame, SQLContext }
import java.util.Calendar
import java.text.SimpleDateFormat

object CargaDirecArtist extends App{

  final val hostName = "quickstart.cloudera"
  final val HDFSPath = "/user/cloudera/mrec/"
  final val artIdHDFSDirectory = "artIdNum/"  
  
  val conf = new SparkConf().setMaster("local[*]").setAppName("Spark con Hive")
  
  System.setProperty("hive.metastore.uris", "thrift://" + hostName + ":9083");
  val sc = new SparkContext(conf)
  val hiveContext = new HiveContext(sc)

  try {
    // consulta Hive para obtener artid diferentes:
    val ratingsDF: DataFrame = hiveContext.sql("SELECT artidnum, artid, artname FROM practica.artidwithnum")
    
    // lo transformo en un RDD de texto
    val cadArtis:RDD[String] = ratingsDF.map { x =>  
       new String(s"${x.get(0).toString()}\t${x.get(1).toString()}\t${x.get(2).toString()}")}

    // fecha de hoy
    val now = Calendar.getInstance().getTime()
    val formatter = new SimpleDateFormat("YYYY-MM-dd")
    val cadNow = formatter.format(now)    
    
    // guardar la consulta en directorio hdfs
    val ruta = "hdfs://" + hostName + ":8020" + HDFSPath + artIdHDFSDirectory + cadNow
    cadArtis.saveAsTextFile(ruta)
    
    // crear tabla hive que referencia ese directorio
    
  } finally {
    sc.stop()
  }
  
}