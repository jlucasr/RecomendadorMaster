package als

import org.apache.hadoop.hbase.client.Get
import org.apache.hadoop.hbase._
import org.apache.hadoop.hbase.client._
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.{ SparkContext, SparkConf}
import org.apache.spark.rdd._
import org.apache.hadoop.hbase.spark._
import java.util.Calendar
import java.text.SimpleDateFormat 
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.{ DataFrame, SQLContext ,Row}
import org.apache.spark.ml.recommendation.{ ALSModel, ALS }

case class Artist (val artidnum:Int, val artid: String, val artname: String)

object CargaArtistHBase extends App{

  final val hostName = "quickstart.cloudera"
  final val zookeeperNodeHBase = "/hbase"
  final val namespaceName = "nsmrec"
  final val artistsTableName = "artists"
  final val HDFSPath = "/user/cloudera/mrec/"
  final val artistsHDFSDirectory = "artists/"  
  
  val conf = new SparkConf().setMaster("local[*]").setAppName("Recomendador Spark")
  val sc = new SparkContext(conf) 

  val hbaseConf = HBaseConfiguration.create()
  //esto puede cambiar dependiendo de hostname
  hbaseConf.set("hbase.zookeeper.quorum", hostName)
  hbaseConf.set("hbase.zookeeper.property.clientPort", "2181");
  //esto puede cambiar dependiendo de la propiedad de zookeeper
  hbaseConf.set("zookeeper.znode.parent", zookeeperNodeHBase);
  
  val hbaseConn = ConnectionFactory.createConnection(hbaseConf);

  val hbaseContext = new HBaseContext(sc, hbaseConf);

  val admin = hbaseConn.getAdmin()
  val nameSpace = NamespaceDescriptor.create(namespaceName).build();
  val desc =  admin.listNamespaceDescriptors();
  var existe = false;
  for( a1:NamespaceDescriptor <- desc){
    if (a1.getName.equals(namespaceName)){
      existe=true  
    }
  }
  if (!existe){
     admin.createNamespace(nameSpace)
  }
  
  //crear la tabla de banner si no existe
  val tableName = TableName.valueOf(namespaceName + ":" + artistsTableName)
  val tabledescriptor = new HTableDescriptor(tableName);
  val nameFam = "data".getBytes()
  val familyDatos = new HColumnDescriptor(nameFam);
  tabledescriptor.addFamily(familyDatos);
  familyDatos.setMaxVersions(1)
  if (!admin.tableExists(tableName)) {
    admin.createTable(tabledescriptor);
  }
  val table = hbaseConn.getTable(tableName);
  
  // fecha de hoy
  val now = Calendar.getInstance().getTime()
  val formatter = new SimpleDateFormat("YYYY-MM-dd")
  val cadNow = formatter.format(now)

  val ruta = "hdfs://" + hostName + ":8020" + HDFSPath + artistsHDFSDirectory + cadNow
  val artistNames = sc.textFile(ruta)  
  
  hbaseContext.bulkPut[String](artistNames,
    tableName,
    (putRecord) => {
      val fields = putRecord.split('\t')
      val clave = fields(0)
      val artid = fields(1)
      val artname = fields(2)
    
      println(s"Inserting artist record : $clave, $artid, $artname")
      
      val put = new Put(Bytes.toBytes(clave))       
      put.addColumn(nameFam, "artid".getBytes(), artid.getBytes())
      put.addColumn(nameFam, "artname".getBytes(), artname.getBytes())
      put   
      
   });
  
  
}