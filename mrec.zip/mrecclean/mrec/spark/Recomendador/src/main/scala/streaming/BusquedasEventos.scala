package streaming

trait BusquedasEventos {
  
  protected val  NUM_EVENTOS_BANNER = 3
  
  def getBanner(age: Integer, sex: String): String =
    (age, sex) match {
      case (x, y) if (x >= 0 && x < 10) && sex.equalsIgnoreCase("m") => "0-10m"
      case (x, y) if (x >= 10 && x < 20) && sex.equalsIgnoreCase("m") => "10-20m"
      case (x, y) if (x >= 20 && x < 30) && sex.equalsIgnoreCase("m") => "20-30m"
      case (x, y) if (x >= 30 && x < 40) && sex.equalsIgnoreCase("m") => "30-40m"
      case (x, y) if (x >= 40 && x < 60) && sex.equalsIgnoreCase("m") => "40-60m"
      case (x, y) if (x >= 60 && x < 80) && sex.equalsIgnoreCase("m") => "60-80m"
      case (x, y) if (x >= 80 && x < 100) && sex.equalsIgnoreCase("m") => "80-100m"

      case (x, y) if (x >= 0 && x < 10) && sex.equalsIgnoreCase("f") => "0-10f"
      case (x, y) if (x >= 10 && x < 20) && sex.equalsIgnoreCase("f") => "10-20f"
      case (x, y) if (x >= 20 && x < 30) && sex.equalsIgnoreCase("f") => "20-30f"
      case (x, y) if (x >= 30 && x < 40) && sex.equalsIgnoreCase("f") => "30-40f"
      case (x, y) if (x >= 40 && x < 60) && sex.equalsIgnoreCase("f") => "40-60f"
      case (x, y) if (x >= 60 && x < 80) && sex.equalsIgnoreCase("f") => "60-80f"
      case (x, y) if (x >= 80 && x < 100) && sex.equalsIgnoreCase("f") => "80-100f"
      case _ => null

    }
}